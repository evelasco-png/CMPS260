//
//  main.cpp
//  quiz2
//
//  Created by eli velasco on 10/29/25.
//

#include <iostream>
#include <iomanip>
using namespace std;
double num1 = 0, num2 = 0, num3 = 0, num4 = 0, total = 0, total2 = 0, total3 = 0, total4 = 0, total5 = 0, tax = 0, tax_amount = 0;

int main() {
    cout << "welcome to the coffee shop calculator" <<endl;
    cout << right << setw(45) << setfill('-')<< "-"<<fixed<< endl; // divider
    cout << "enter number of small coffee(s): ";
    cin >> num1; // amount of small coffees
    int sml = num1;
    total = num1*2.25; // amount of small coffees * the price of a small coffee
    cout << "enter number of medium coffee(s): ";
    cin >> num2; // amount of medium coffees
    int med = num2;
    total2 = num2*3; // amount of medium coffees * the price of a medium coffee
    cout << "enter number of large coffee(s): ";
    cin >> num3; // amount of large coffees
    int lrg = num3;
    total3 = num3*3.75; // amount of large coffes * the price of a large coffee
    total4 = total+total2+total3; // calculate the subtotal
    cout << "enter tax rate (%): ";
    cin >> num4; // tax rate
    tax = num4/100; // converts tax rate to decimal
    tax_amount = tax*total4; // tax rate * subtotal
    total5 = total4+tax_amount; // subtotal + tax amount to find the total cost
    cout << right << setw(45) << setfill('-')<< "-"<<fixed<< endl; // divider
    cout << "order receipt:" <<endl;
    cout << left << "small coffee(s)(" << sml << " x $2.25)"<<setw(15) << setfill('.')<< right<<"$" <<fixed<<
    setprecision(2) << total << endl;
    cout << left << "medium coffee(s)(" << med << " x $3.00)"<<setw(14) << setfill('.')<< right<<"$" <<fixed<<
    setprecision(2) << total2 << endl;
    cout << left << "large coffee(s)(" << lrg << " x $3.75)"<<setw(15) << setfill('.')<< right<<"$" <<fixed<<
    setprecision(2) << total3 << endl;
    cout << right << setw(45) << setfill('-')<< "-"<<fixed<< endl;
    cout << setw(40) << setfill('.') << left << "subtotal" << "$" << fixed <<
    setprecision(2) << total4 << endl;
    cout <<left << "tax(" << num4 << "%)"<<setw(31) << setfill('.')<< right<<"$" <<fixed<<
    setprecision(2) << total2 << endl;
    cout << setw(40) << setfill('.') << left << "total" << "$" << fixed <<
    setprecision(2) << total5 << endl;
    cout << right << setw(45) << setfill('-')<< "-"<<fixed<< endl;
    cout << "thank you for supporting a local coffee shop!" << endl;
    return 0;
}

